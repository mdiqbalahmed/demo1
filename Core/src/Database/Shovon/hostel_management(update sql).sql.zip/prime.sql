-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 25, 2024 at 12:53 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prime`
--

-- --------------------------------------------------------

--
-- Table structure for table `hostel_allotements`
--

CREATE TABLE `hostel_allotements` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `std_id` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `building_id` bigint(20) UNSIGNED NOT NULL,
  `room_id` bigint(20) UNSIGNED NOT NULL,
  `student_cycle_id` bigint(20) UNSIGNED NOT NULL,
  `extra` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 CHECKSUM=1 COLLATE=utf8_unicode_ci DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `hostel_allotements`
--

INSERT INTO `hostel_allotements` (`id`, `std_id`, `building_id`, `room_id`, `student_cycle_id`, `extra`) VALUES
(1, '2401001', 1, 1, 23, 0),
(2, '2401002', 1, 1, 24, 0),
(3, '2402004', 1, 1, 33, 0);

-- --------------------------------------------------------

--
-- Table structure for table `hostel_buildings`
--

CREATE TABLE `hostel_buildings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `hostel_id` int(10) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 CHECKSUM=1 COLLATE=utf8_unicode_ci DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `hostel_buildings`
--

INSERT INTO `hostel_buildings` (`id`, `hostel_id`, `name`, `description`, `created`, `modified`) VALUES
(1, 1, 'Boys Hostel', '', '2024-04-25 10:13:45', '2024-04-25 10:13:45');

-- --------------------------------------------------------

--
-- Table structure for table `hostel_hostels`
--

CREATE TABLE `hostel_hostels` (
  `id` int(10) NOT NULL,
  `hostel_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hostel_hostels`
--

INSERT INTO `hostel_hostels` (`id`, `hostel_name`) VALUES
(1, 'Boys');

-- --------------------------------------------------------

--
-- Table structure for table `hostel_rooms`
--

CREATE TABLE `hostel_rooms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `building_id` bigint(20) UNSIGNED NOT NULL,
  `hostel_id` bigint(20) NOT NULL,
  `room_type_id` bigint(20) NOT NULL,
  `room_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seat` bigint(20) DEFAULT NULL,
  `extra` bigint(20) NOT NULL,
  `status` bigint(20) NOT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 CHECKSUM=1 COLLATE=utf8_unicode_ci DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `hostel_rooms`
--

INSERT INTO `hostel_rooms` (`id`, `building_id`, `hostel_id`, `room_type_id`, `room_number`, `seat`, `extra`, `status`, `created`, `modified`) VALUES
(1, 1, 1, 1, '7270', 5, 0, 3, '2024-04-25 10:14:14', '2024-04-25 10:51:24');

-- --------------------------------------------------------

--
-- Table structure for table `hostel_room_type`
--

CREATE TABLE `hostel_room_type` (
  `id` int(10) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hostel_room_type`
--

INSERT INTO `hostel_room_type` (`id`, `type`) VALUES
(1, 'Premium type');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hostel_allotements`
--
ALTER TABLE `hostel_allotements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_allotements` (`room_id`),
  ADD KEY `FK_allotements_vs_students` (`student_cycle_id`);

--
-- Indexes for table `hostel_buildings`
--
ALTER TABLE `hostel_buildings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hostel_hostels`
--
ALTER TABLE `hostel_hostels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hostel_rooms`
--
ALTER TABLE `hostel_rooms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_rooms` (`building_id`);

--
-- Indexes for table `hostel_room_type`
--
ALTER TABLE `hostel_room_type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hostel_allotements`
--
ALTER TABLE `hostel_allotements`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `hostel_buildings`
--
ALTER TABLE `hostel_buildings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hostel_hostels`
--
ALTER TABLE `hostel_hostels`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hostel_rooms`
--
ALTER TABLE `hostel_rooms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hostel_room_type`
--
ALTER TABLE `hostel_room_type`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `hostel_rooms`
--
ALTER TABLE `hostel_rooms`
  ADD CONSTRAINT `FK_rooms` FOREIGN KEY (`building_id`) REFERENCES `hostel_buildings` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
